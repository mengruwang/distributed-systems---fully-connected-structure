package activitystreamer.util;

public class ClientRecord {
	
	private String loginTime;
	
	private String logoutTime;
	
	private String serverInfo;
	
	
	public ClientRecord(String loginTime, String logoutTime, String serverInfo) {
		
		this.loginTime = loginTime;
		
		this.logoutTime = logoutTime;
		
		this.serverInfo =serverInfo;
	}
	
	
   public ClientRecord(String loginTime, String serverInfo) {
		
		this.loginTime = loginTime;
		
		this.serverInfo =serverInfo;
	}



	public String getLoginTime() {
		return loginTime;
	}



	public void setLoginTime(String loginTime) {
		this.loginTime = loginTime;
	}



	public String getLogoutTime() {
		return logoutTime;
	}



	public void setLogoutTime(String logoutTime) {
		this.logoutTime = logoutTime;
	}



	public String getServerInfo() {
		return serverInfo;
	}



	public void setServerInfo(String serverInfo) {
		this.serverInfo = serverInfo;
	}
	
	

}
