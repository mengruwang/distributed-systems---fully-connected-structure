package activitystreamer.server;


import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import activitystreamer.util.ClientRecord;
import activitystreamer.util.Settings;


public class Connection extends Thread {
	private static final Logger log = LogManager.getLogger();
	private DataInputStream in;
	private DataOutputStream out;
	private BufferedReader inreader;
	private PrintWriter outwriter;
	private boolean open = false;
	private Socket socket;
	private boolean term=false;
	private boolean exception = false;
	private DateFormat dateformat = new  SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SSS");
	
	Connection(Socket socket) throws IOException{
		in = new DataInputStream(socket.getInputStream());
	    out = new DataOutputStream(socket.getOutputStream());
	    inreader = new BufferedReader( new InputStreamReader(in));
	    outwriter = new PrintWriter(out, true);
	    this.socket = socket;
	    open = true;            
	    start();
	}
	
	/*
	 * returns true if the message was written, otherwise false
	 */
	public boolean writeMsg(String msg) {
		if(open){
			outwriter.println(msg);
			outwriter.flush();
			return true;	
		}
		return false;
	}
	
	public void closeCon(){
		if(open){
			log.info("closing connection "+Settings.socketAddress(socket));
			try {
				term=true;
				inreader.close();
				out.close();
				in.close();
				socket.close();
			} catch (IOException e) {
				// already closed?
				log.error("received exception closing the connection "+Settings.socketAddress(socket)+": "+e);
			}
		}
	}
	
	
	public void run(){
		String socketaddress = Settings.socketAddress(socket).split("/")[1];
		GsonBuilder gsonMapBuilder = new GsonBuilder();
	    Gson gsonObject = gsonMapBuilder.create();
		try {

			//connection is initially join in system, send authenticate to a server 
			
			if(Settings.getRemoteHostname()!=null && Settings.getRemoteHostname().compareTo(socket.getInetAddress().getHostName())==0 &&
				Settings.getRemotePort() == socket.getPort()) {
				JSONObject json = new JSONObject();
				json.put("command", "AUTHENTICATE");
				json.put("secret",Settings.getSecret());
				InetAddress address = InetAddress.getByName(Settings.getLocalHostname()); 
				int serverPort= Settings.getLocalPort();
				String serverAddress = address.getHostAddress() + ":" + serverPort;
				
				if(socketaddress.split(":")[0].compareTo("127.0.0.1")!=0) {
					String IP=InetAddress.getLocalHost().getHostAddress();
					serverAddress = IP+":"+serverPort;
				}

				json.put("serverAddress", serverAddress);
				this.writeMsg(json.toString());
				Settings.addAuthenticatedServer(socketaddress, socketaddress);
			}
			//send auth_connection to other authenticated servers
			if(Settings.getAuthConnections().contains(socketaddress)){
				log.info("sending AUTH_CONNECT to:  " + socketaddress );
				JSONObject json = new JSONObject();
				json.put("command", "AUTH_CONNECT");
				json.put("secret",Settings.getSecret());
				InetAddress address = InetAddress.getByName(Settings.getLocalHostname()); 
				int serverPort= Settings.getLocalPort();
				String serverAddress = address.getHostAddress() + ":" + serverPort;
				json.put("serverAddress", serverAddress);
				this.writeMsg(json.toString());
				Settings.addAuthenticatedServer(socketaddress, socketaddress);
				Settings.deleteAuthConnection(socketaddress);	
			}
			// send sync message to recover the connection and messages 
			if(Settings.getRecoverConnection().contains(socketaddress)){
				log.info("sending RE_CONNECT to:  " + socketaddress );
				JSONObject json = new JSONObject();
				json.put("command", "MESSAGE_SYN");
				json.put("secret",Settings.getSecret());
				//server listening Address
				InetAddress address = InetAddress.getByName(Settings.getLocalHostname()); 
				int serverPort= Settings.getLocalPort();
				String serverAddress = address.getHostAddress() + ":" + serverPort;
				json.put("serverAddress", serverAddress);
				//received messages list
				Map<String, LinkedList<JSONObject>> tmp_map = new HashMap<String, LinkedList<JSONObject>>();
				tmp_map.put("messages", Settings.getMessage_queue());
			    String tmp_messages = gsonObject.toJson(tmp_map);
				JSONObject sent_messages;
				try {
					sent_messages = (JSONObject) new JSONParser().parse(tmp_messages);
					json.put("messages", sent_messages);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				this.writeMsg(json.toString());
				Settings.addAuthenticatedServer(socketaddress, socketaddress);
				Settings.deleteRecoverConnection(socketaddress);
			}
			String data;
			// receive data from stream
			while(!term && (data = inreader.readLine())!=null){
				term=Control.getInstance().process(this,data);
			}
			log.debug("connection closed to "+Settings.socketAddress(socket));
			this.closeCon();
			Control.getInstance().connectionClosed(this);

		} catch (IOException e) {
			log.info("exception occured");
			log.error("connection "+Settings.socketAddress(socket)+" closed with exception: "+e);
			exception = true;
			this.closeCon();
			Control.getInstance().connectionClosed(this);

		}finally {
        	// if connection is from a server, remove that server from storage
    		if(Settings.getAuthenticatedServers().containsKey(socketaddress)){
    			String serverAddress = Settings.getAuthenticatedServers().get(socketaddress);
    			//remove from authenticated list
    			Settings.removeAuthenticatedServer(socketaddress);
    			//remove from server announcement list
    			log.info("ready to remove server :" + serverAddress + " from the system");
    			Settings.removeServerAnounce(serverAddress);
    			log.info("successfully remove server :" + serverAddress + " from the system");
    		}
    		// if connection is outgoing connection to a server
    		// try to make a new connection to the server 
    		if(Settings.getOutConnections().contains(socketaddress)) {
    			log.info("outgoing connection closed");
    			//remove outgoing server connection
    			Settings.deleteOutConnection(socketaddress); 
    			//parse hostname and port
    			String hostname = socketaddress.split(":")[0];
    			String port = socketaddress.split(":")[1];
    			// timeout connections
    			if(exception) {
    				log.info("try reconnect when exception is true");
    				while(exception){
    	    			try {
    	    				log.info("try to make a new connection to" + socketaddress);
    	    				 Control.getInstance().outgoingConnection(new Socket(hostname,Integer.parseInt(port)));
    	    				 exception = false;
    	    				 Settings.addRecoverConnection(socketaddress);
    	    			} catch (IOException e) {
    	    				 exception = true;
    	    				log.error("can not recovering the connection to "+socketaddress+e);
    	    			}
        			}	
    			}
    			//disconnected connections
    			else {
    				log.info("try reconnect when exception is false");
    				try {
	    				 Control.getInstance().outgoingConnection(new Socket(hostname,Integer.parseInt(port)));
	    				 Settings.addRecoverConnection(socketaddress);
	    			} catch (IOException e) {
	    				log.error("can not recovering the connection to "+socketaddress+e);
	    			}
    			}
    		}

    		// if connection is incoming connection from a server
    		if(Settings.getIncomingConnection().containsKey(socketaddress)) {
    			Settings.deleteIncomingConnection(socketaddress);
    		}
    		
    		//if connections is a login client, logout that client
    		if(Settings.getLoggedUsers().containsKey(socketaddress)) {
    			
    			Settings.removeLoad();

    			  //get username
				String logoutTime = dateformat.format(new Date());
				String username = Settings.getLoggedUsers().get(socketaddress);
				ClientRecord cr = Settings.getClient_records().get(username);
				cr.setLogoutTime(logoutTime);
				Settings.addClient_records(username, cr);
				
				JSONObject logout  = new JSONObject();
				logout.put("command", "CLIENT_UPDATE");
				logout.put("username", username);
				logout.put("type", "LOGOUT");
				String recordInString = new Gson().toJson(cr);
				logout.put("info", recordInString);
				
				 //remove this connection and user info from logged list
		        Settings.removeLoggedUser(socketaddress);
				//broadcast
		        ArrayList<Connection> connections = Control.getInstance().getConnections();
				for (int i =0; i<connections.size(); i++) {
					String socket_info = Settings.socketAddress(connections.get(i).getSocket()).split("/")[1];
					if(Settings.getAuthenticatedServers().containsKey(socket_info)) {
						connections.get(i).writeMsg(logout.toString());	
					}
				}
    		}	
        }
		open=false;

	}
	
	public Socket getSocket() {
		return socket;
	}
	
	public boolean isOpen() {
		return open;
	}
}
